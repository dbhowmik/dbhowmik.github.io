1. Open the MAKE file to change the .tex file you want to compile.
2. On linux terminal run
$make
3. If it does not compile for the first time check the terminal for error messages. You may have to install 'rubber' package.
4. For any other error check the terminal error messages. Fix one by one. 